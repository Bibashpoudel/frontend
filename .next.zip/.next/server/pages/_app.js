(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 5204:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ App)
});

// EXTERNAL MODULE: ./styles/globals.css
var globals = __webpack_require__(6764);
// EXTERNAL MODULE: ./node_modules/next/script.js
var script = __webpack_require__(4298);
var script_default = /*#__PURE__*/__webpack_require__.n(script);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./utils/gtab.js
const pageview = url => {
  window.gtag("config", process.env.GOOGLE_ANALYTIC, {
    page_path: url
  });
};
const gtab_event = ({
  action,
  category,
  label,
  value
}) => {
  window.gtag("event", action, {
    event_category: category,
    event_label: label,
    value
  });
};
;// CONCATENATED MODULE: external "@reduxjs/toolkit"
const toolkit_namespaceObject = require("@reduxjs/toolkit");
// EXTERNAL MODULE: ./redux/constant/news.constants.ts
var news_constants = __webpack_require__(4175);
;// CONCATENATED MODULE: ./redux/reducers/news.reducer.ts

const newsReducer = (state = {}, action) => {
  switch (action.type) {
    case news_constants/* NEWS_SUBMIT_LOADING */.Jc:
      return {
        loading: true
      };

    case news_constants/* NEWS_SUBMIT_SUCCESS */.RR:
      return {
        loading: false,
        success: action.payload
      };

    case news_constants/* NEWS_SUBMIT_FAIL */.cc:
      return {
        loading: false,
        error: action.payload
      };

    default:
      return state;
  }
};
const contactUsReducer = (state = {}, action) => {
  switch (action.type) {
    case news_constants/* CONTACT_US_LOADING */.w:
      return {
        loading: true
      };

    case news_constants/* CONTACT_US_SUCCESS */.g0:
      return {
        loading: false,
        success: action.payload
      };

    case news_constants/* CONTACT_US_FAIL */.m2:
      return {
        loading: false,
        error: action.payload
      };

    default:
      return state;
  }
};
// EXTERNAL MODULE: ./redux/constant/user.constants.ts
var user_constants = __webpack_require__(6473);
;// CONCATENATED MODULE: ./redux/reducers/user.reducer.ts

const userSigninReducer = (state = {}, action) => {
  switch (action.type) {
    case user_constants/* USER_SIGNIN_REQUEST */.Kt:
      return {
        loading: true
      };

    case user_constants/* USER_SIGNIN_SUCCESS */.GW:
      return {
        loading: false,
        userInfo: action.payload
      };

    case user_constants/* USER_SIGNIN_FAIL */.PO:
      return {
        loading: false,
        error: action.payload
      };

    case user_constants/* USER_SIGNOUT */.KY:
      return {};

    default:
      return state;
  }
};
;// CONCATENATED MODULE: ./utils/store.ts


 // ...

const store = (0,toolkit_namespaceObject.configureStore)({
  reducer: {
    subscribe: newsReducer,
    contatcUs: contactUsReducer,
    userSignin: userSigninReducer
  }
}); // Infer the `RootState` and `AppDispatch` types from the store itself
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./pages/_app.tsx
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }











function App({
  Component,
  pageProps
}) {
  const router = (0,router_.useRouter)();
  (0,external_react_.useEffect)(() => {
    const handleRouteChange = url => {
      pageview(url);
    };

    router.events.on("routeChangeComplete", handleRouteChange);
    return () => {
      router.events.off("routeChangeComplete", handleRouteChange);
    };
  }, [router.events]);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/jsx_runtime_.jsx((script_default()), {
      strategy: "afterInteractive",
      src: `https://www.googletagmanager.com/gtag/js?id=${"G-VEVCC7T1VL"}`
    }), /*#__PURE__*/jsx_runtime_.jsx((script_default()), {
      id: "google-analytics",
      strategy: "afterInteractive",
      dangerouslySetInnerHTML: {
        __html: `
          window.dataLayer = window.dataLayer || [];
          function gtag(){dataLayer.push(arguments);}
          gtag('js', new Date());
          gtag('config', "${"G-VEVCC7T1VL"}", {
            page_path: window.location.pathname,
          });
        `
      }
    }), /*#__PURE__*/jsx_runtime_.jsx(external_react_redux_.Provider, {
      store: store,
      children: /*#__PURE__*/jsx_runtime_.jsx(Component, _objectSpread({}, pageProps))
    })]
  });
}

/***/ }),

/***/ 4175:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Jc": () => (/* binding */ NEWS_SUBMIT_LOADING),
/* harmony export */   "RR": () => (/* binding */ NEWS_SUBMIT_SUCCESS),
/* harmony export */   "cc": () => (/* binding */ NEWS_SUBMIT_FAIL),
/* harmony export */   "g0": () => (/* binding */ CONTACT_US_SUCCESS),
/* harmony export */   "m2": () => (/* binding */ CONTACT_US_FAIL),
/* harmony export */   "w": () => (/* binding */ CONTACT_US_LOADING)
/* harmony export */ });
const NEWS_SUBMIT_LOADING = "NEWS_SUBMIT_LOADING";
const NEWS_SUBMIT_SUCCESS = "NEWS_SUBMIT_SUCCESS";
const NEWS_SUBMIT_FAIL = "NEWS_SUBMIT_FAIL";
const CONTACT_US_LOADING = "CONTACT_US_LOADING";
const CONTACT_US_SUCCESS = "CONTACT_US_SUCCESS";
const CONTACT_US_FAIL = "CONTACT_US_FAIL";

/***/ }),

/***/ 6473:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GW": () => (/* binding */ USER_SIGNIN_SUCCESS),
/* harmony export */   "KY": () => (/* binding */ USER_SIGNOUT),
/* harmony export */   "Kt": () => (/* binding */ USER_SIGNIN_REQUEST),
/* harmony export */   "PO": () => (/* binding */ USER_SIGNIN_FAIL)
/* harmony export */ });
const USER_SIGNIN_REQUEST = "USER_SIGNIN_REQUEST";
const USER_SIGNIN_SUCCESS = "USER_SIGNIN_SUCCESS";
const USER_SIGNIN_FAIL = "USER_SIGNIN_FAIL";
const USER_SIGNOUT = "USER_SIGNOUT";

/***/ }),

/***/ 6764:
/***/ (() => {



/***/ }),

/***/ 4298:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__(7829)


/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 6405:
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ 6022:
/***/ ((module) => {

"use strict";
module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [398,829], () => (__webpack_exec__(5204)));
module.exports = __webpack_exports__;

})();