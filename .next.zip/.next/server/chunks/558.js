"use strict";
exports.id = 558;
exports.ids = [558];
exports.modules = {

/***/ 8558:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ AdminLayout)
/* harmony export */ });
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _utils_getSession__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7981);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _redux_actions_user_action__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2175);
/* harmony import */ var _redux_constant_user_constants__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6473);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_redux_actions_user_action__WEBPACK_IMPORTED_MODULE_5__]);
_redux_actions_user_action__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];











function AdminLayout({
  title,
  description,
  children
}) {
  const {
    0: sidebar,
    1: setSideBar
  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(true);
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
  const path = router.pathname.split("#");
  const session = (0,_utils_getSession__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z)();
  (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(() => {
    const abc = localStorage.getItem("userInfo") ? JSON.parse(localStorage.getItem("userInfo")) : null;

    if (!session) {
      router.push("/admin/login");
    }
  }, []);
  const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_4__.useDispatch)();

  function logout(path) {
    dispatch((0,_redux_actions_user_action__WEBPACK_IMPORTED_MODULE_5__/* .signout */ .u)());
    dispatch({
      type: _redux_constant_user_constants__WEBPACK_IMPORTED_MODULE_8__/* .USER_SIGNOUT */ .KY
    });
    router.push(`${path}`);
  }

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.Fragment, {
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_0___default()), {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("title", {
        children: title ? title + " - Pace Code" : "Pace Code"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("meta", {
        content: "Gurzu",
        name: "author",
        style: {
          userSelect: "text"
        }
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("meta", {
        content: "enterprise solution, product development, develop software, apps developer, agile for software development, create software, software coding, companies software development, application software developers, custom-developed software, app developer software, custom software development companies, process development software, software developing companies, app build software, methodology software development, software outsourcing, custom software, engineering software development, app create software, building software, website software, agile methodologies for software development, software company, Node, nodejs, Nextjs, nextjs, nestjs, nest, react, reactjs, reactnative, flutter, iOS development, android development,   python, django framework, django, restAPI, RESTAPI, restapi, nodejs, vue js, typescript,  digital signage, display network, building your own website, digital experience, customer software management, javascript, outsourcing business, team augmentation, pace code, pace, code, pacecode",
        name: "keywords",
        style: {
          userSelect: "text"
        }
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("meta", {
        name: "description",
        content: description ? description : "",
        style: {
          userSelect: "text"
        }
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("meta", {
        httpEquiv: "x-ua-compatible",
        content: "ie=edge",
        style: {
          userSelect: "text"
        }
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("meta", {
        httpEquiv: "Cache-control",
        content: "private",
        style: {
          userSelect: "text"
        }
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("meta", {
        name: "viewport",
        content: "width=device-width, initial-scale=1",
        style: {
          userSelect: "text"
        }
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("link", {
        rel: "icon",
        href: "/images/logo.png",
        type: "image/x-icon"
      })]
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)("div", {
      className: "flex  min-h-screen  flex-col justify-between",
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)("div", {
        className: "flex ",
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)("nav", {
          className: "shadow-md  admin-sidebar w-96  max-sm:w-16",
          style: sidebar ? {
            height: "100vh"
          } : {
            height: "100vh",
            width: "4rem"
          },
          children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)("div", {
            className: "flex justify-center",
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
              src: "/images/logo.png",
              width: 100,
              height: 100,
              alt: "logo"
            }), " "]
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("div", {
            className: "",
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("ul", {
              children: [{
                name: "Dashboard",
                path: "/admin"
              }, {
                name: " User",
                path: "/admin/users"
              }, {
                name: "Inquire",
                path: "/admin/inquire"
              }, {
                name: "settings ",
                path: "/admin/settings"
              }, {
                name: "blog",
                path: "/admin/blog"
              }, {
                name: "Jobs",
                path: "/admin/add-jobs"
              }, {
                name: "Log out ",
                path: "/admin/login"
              }].map((a, index) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.Fragment, {
                children: sidebar ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("li", {
                  className: router.pathname == `${a.path}` ? "pl-10 p-2 bg-primary cursor-pointer max-sm:hidden" : "pl-10 p-2 cursor-pointer max-sm:hidden",
                  onClick: () => logout(a.path),
                  children: a.name
                }, index) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("li", {
                  className: "text-red-500"
                }, index)
              }))
            })
          })]
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)("div", {
          className: "flex flex-col w-full",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("header", {
            className: "flex w-full h-12 bg-white shadow-md items-center",
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("div", {
              className: " ",
              children: sidebar ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("div", {
                onClick: () => setSideBar(false),
                children: "hide bar"
              }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("div", {
                onClick: () => setSideBar(true),
                children: "show bar"
              })
            })
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)("main", {
            className: "p-4 overflow-y-scroll",
            style: {
              height: "93vh"
            },
            children: [" ", children]
          })]
        })]
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("footer", {
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("div", {
          className: " flex h-10  justify-center items-center shadow-inner",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("div", {
            children: "Copyright \xA9 2022 Pace Code"
          })
        })
      })]
    })]
  });
}
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7981:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ getSession)
/* harmony export */ });
function getSession() {
  let sessionUser = null;

  if (typeof sessionStorage !== "undefined") {
    sessionUser = sessionStorage.getItem("user");

    if (sessionUser) {
      sessionUser = JSON.parse(sessionUser);
    }
  }

  return sessionUser;
}

/***/ })

};
;