"use strict";
exports.id = 175;
exports.ids = [175];
exports.modules = {

/***/ 2175:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Y": () => (/* binding */ Signin),
/* harmony export */   "u": () => (/* binding */ signout)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
/* harmony import */ var _constant_user_constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6473);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const URL = "http://localhost:5001/api/v1";
const Signin = (email, password) => async dispatch => {
  dispatch({
    type: _constant_user_constants__WEBPACK_IMPORTED_MODULE_1__/* .USER_SIGNIN_REQUEST */ .Kt,
    payload: {
      email,
      password
    }
  });

  try {
    const {
      data
    } = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].post(`${URL}/auth/login`, {
      username: email,
      password
    }, {
      headers: {
        "Content-Type": "application/json"
      }
    });
    dispatch({
      type: _constant_user_constants__WEBPACK_IMPORTED_MODULE_1__/* .USER_SIGNIN_SUCCESS */ .GW,
      payload: data
    });
    localStorage.setItem("userInfo", JSON.stringify(data));
    sessionStorage.setItem("user", JSON.stringify(data));
  } catch (error) {
    dispatch({
      type: _constant_user_constants__WEBPACK_IMPORTED_MODULE_1__/* .USER_SIGNIN_FAIL */ .PO,
      payload: error.response && error.response.data.message ? error.response.data.message : error.response.data.detail ? error.response.data.detail : error.message ? error.message : error
    });
  }
};
const signout = () => dispatch => {
  localStorage.removeItem("userInfo");
  localStorage.removeItem("cartItems");
  localStorage.removeItem("profile");
  sessionStorage.removeItem("user");
  dispatch({
    type: _constant_user_constants__WEBPACK_IMPORTED_MODULE_1__/* .USER_SIGNOUT */ .KY
  });
};
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6473:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GW": () => (/* binding */ USER_SIGNIN_SUCCESS),
/* harmony export */   "KY": () => (/* binding */ USER_SIGNOUT),
/* harmony export */   "Kt": () => (/* binding */ USER_SIGNIN_REQUEST),
/* harmony export */   "PO": () => (/* binding */ USER_SIGNIN_FAIL)
/* harmony export */ });
const USER_SIGNIN_REQUEST = "USER_SIGNIN_REQUEST";
const USER_SIGNIN_SUCCESS = "USER_SIGNIN_SUCCESS";
const USER_SIGNIN_FAIL = "USER_SIGNIN_FAIL";
const USER_SIGNOUT = "USER_SIGNOUT";

/***/ })

};
;