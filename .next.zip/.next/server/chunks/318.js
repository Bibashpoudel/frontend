"use strict";
exports.id = 318;
exports.ids = [318];
exports.modules = {

/***/ 3318:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Privacy),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5152);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9648);
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(271);
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(sweetalert2__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_2__]);
axios__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






async function getServerSideProps(context) {
  return {
    props: {} // will be passed to the page component as props

  };
}
function Privacy() {
  const editor = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
  const {
    0: content,
    1: setContent
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("");
  const {
    0: data,
    1: setData
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("");
  const {
    0: id,
    1: setId
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("");
  const JoditEditor = next_dynamic__WEBPACK_IMPORTED_MODULE_1___default()(() => Promise.resolve(/* import() */).then(__webpack_require__.t.bind(__webpack_require__, 8167, 23)), {
    ssr: true,
    loadableGenerated: {
      modules: ["admin/components/Privacy.tsx -> " + "jodit-react"]
    }
  });
  const config = {
    placeholder: "start writing...."
  };

  const submit = async () => {
    try {
      const {
        data
      } = await axios__WEBPACK_IMPORTED_MODULE_2__["default"].patch(`http://localhost:5001/api/v1/setting/add-privacy/${id}`, {
        privacyData: content
      }, {
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*"
        }
      });

      if (data) {
        sweetalert2__WEBPACK_IMPORTED_MODULE_3___default().fire("Successfull!", "Your message has been delivered!", "success");
      }
    } catch (error) {}
  };

  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    try {
      const fetchData = async () => {
        const {
          data
        } = await axios__WEBPACK_IMPORTED_MODULE_2__["default"].get("http://localhost:5001/api/v1/setting/privacy");
        console.log(data.data[0].privacyData);
        setContent(data.data[0].privacyData);
        setId(data.data[0]._id);
      };

      fetchData().catch(console.error);
    } catch (error) {
      console.log(error);
    }
  }, [data]);
  console.log(content, id);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)("div", {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("div", {
      className: "",
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(JoditEditor, {
        ref: editor,
        value: content,
        config: config //onChange={(newContent) => setContent(newContent)}
        ,
        onBlur: value => {
          setContent(value);
        } // preferred to use only this option to update the content for performance reasons

      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("div", {
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("input", {
        type: "submit",
        value: "Add",
        className: " w-full rounded-md border py-3 button-primary text-base cursor-pointer transition ",
        onClick: () => submit()
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("div", {
      dangerouslySetInnerHTML: {
        __html: content
      }
    })]
  });
}
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;